package com.saib.util;

public class Results {

	public static final String SUCCESS="success";
	public static final String FAILURE="failure";
}
